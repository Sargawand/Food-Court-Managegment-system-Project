import mysql.connector
import pandas as pd
from tabulate import tabulate
# import datetime as dt
from datetime import datetime,timedelta

# Get the current date and time
current_datetime = datetime.now()

# Format the date and time as a string
formatted_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
previous_time = current_datetime - timedelta(minutes=30)
previous_time_str = previous_time.strftime("%Y-%m-%d %H:%M:%S")
# print(formatted_datetime)s
# print(previous_time_str)
# Print the formatted date and time
# print("Formatted Date and Time:", formatted_datetime)
# total_price=price*int(quantity)
lslogin=[]

Sum_OF_Order=[]
lsoreredmenu=[]
# from mainmenu import MenuOption
class TABLE:
        
        def __init__(self):
                # print("hakiii")
                pass
        # def createtablesss( ):
        
        def insertuser(self):
                        # Connect to the MySQL server
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')

                        # Create a cursor object
                cursor1 = connection.cursor()

                        # Define the SQL command with placeholders for user input
                insert_sql = "INSERT INTO userrecord (username, name, age, pass1) VALUES (%s, %s, %s, %s)"

                        # Execute the SQL command with user input
                import inde
                cursor1.execute(insert_sql, (inde.username, inde.name, inde.age, inde.pass1))
                connection.commit()
                print("Insert succsfully")
                # from inde import Section
                # objsection=Section()
                # objsection.adminsection()       
                
                
        def menucard(self):
                # self.sss=sss
                # print("in which Brand do You want to add a product:/n1]McD/n2]Burgerking/n3]Naturals/n4]KFC")
                # print("Enter your choise")
                '''connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()
                create_table_menucard = """
                        CREATE TABLE IF NOT EXISTS menucard (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        brandname VARCHAR(255),
                        productname varchar(255),
                        priceR int,
                        priceM int,
                        priceL int
                        )
                        """     
                # try:
        
                # cursor1.execute(create_table_menucard)
                        
                        # print("table created")
                
                        # ("Table allready exist")'''
                import mysql.connector
# import pandas as pd

                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()

                # print("1]Macdee\n2]BurgerKing\n3]Naturals")
                query='select distinct brandname from menucard'
                cursor1.execute(query)
                result=cursor1.fetchall()
                # print(result)
                n = 1
                brandnamelist = []
                for i in result:
                        brandnamelist.append(i[0])  # Extracting the brand name from the tuple
                        print(n, " ", i[0])
                        n += 1

                # Get user input for brand name
                while True:
                        br = input("Enter No To view menu:\nPress Q for back  ")
                        if br=="q" or br=="Q":
                                break
                # Construct the SQL query based on user input
                        elif br.isdigit() and 1 <= int(br) <= len(brandnamelist):
                                selected_brand = brandnamelist[int(br) - 1]
                                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                cursor1 = connection.cursor()
                                query = f'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname = %s'
                                import warnings

                                # Suppress UserWarning from pandas
                                warnings.filterwarnings("ignore", category=UserWarning)

        # Your existing code
                                df = pd.read_sql_query(query, connection, params=(selected_brand,))
                                 # Add a serial number column to the DataFrame
                                # df['Serial No'] = range(1, len(df) + 1)
                                df.insert(0, 'Serial No', range(1, len(df) + 1))
                                print(tabulate(df, headers='keys', tablefmt='pretty', showindex=False))
                                # df_centered = df.style.set_properties(**{'text-align': 'center'}).set_table_styles([dict(selector='th', props=[('text-align', 'center')])])

        # Display the centered DataFrame
                                # print(tabulate(df_centered, headers='keys', tablefmt='pretty', showindex=False))
                                # df = pd.read_sql_query(query, connection, params=(selected_brand,))
                                # print(df)
                        else:
                                print("Invalid input or brand number out of range.")

                        # Close the database connection
                        connection.close()
                #
                # n=1
                # brandnamelist=[]
                # for i in result:
                #         brandnamelist.append(i[0])
                #         print(n," ",i[0])
                #         n+=1
                # # df = pd.read_sql_query(query, connection)
                # # print(df)
                # br = input("Enter No To view menu:\n Or Insert Brand name ")
                # if br == "1":
                #         query = 'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname ="McDonold" '
                # elif br == "2":
                #         query = 'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname ="BurgerKing" '
                # elif br == "3":
                #         query = 'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname ="Naturals" '
                # elif br == "4":  # Note: I changed this to "4" instead of another "3" for variety
                #         query = 'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname ="KFC" '
                # else:
                #         query = 'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname = %s '

                # # Use pandas to read the SQL query result into a DataFrame
                # if br != "4":
                #         df = pd.read_sql_query(query, connection)
                # else:
                #         df = pd.read_sql_query(query, connection, params=(brandnamelist[int(br)-1],))

                # # Display the DataFrame (formatted as a table)
                # print(df)

# Close the database connection
                # connection.close()
    
                        
                
                # connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                # cursor1 = connection.cursor()
                # print("1]Macdee\n2]BurgerKing\n3]Naturals")
                # br=input("Enter No To view menu:\n Or Insert Brand name ")
                
                # if br=="1":
                #         # q='SELECT productname,priceR,priceM,priceL FROM menucard Where brandname ="McDonold" '
                #         # df = pd.read_sql_query(q, connection)
                #         # print(df)

                        
                #         cursor1.execute('SELECT productname,priceR,priceM,priceL FROM menucard Where brandname ="McDonold" ')
                # # print("HHHHHHH")
                # elif br=="2":
                #         cursor1.execute('SELECT productname,priceR,priceM,priceL FROM menucard Where brandname ="BurgerKing" ')
                # elif br=="3":
                #         cursor1.execute('SELECT productname,priceR,priceM,priceL FROM menucard Where brandname ="Naturals" ')
                # elif br=="4":
                #         cursor1.execute('SELECT productname,priceR,priceM,priceL FROM menucard Where brandname ="KFC" ')
                # else:
                         
                #         query='SELECT productname,priceR,priceM,priceL FROM menucard Where brandname = %s '
                #         cursor1.execute(query,(br,))
                        
                        

    
                # records = cursor1.fetchall()
                # print(type(records))
                # print("HHHHHHH")

                # for record in records:
                        # print(record)
                # from inde import Menuoption
                # objm=Menuoption("sarvesh")
                # objm.mainmenufun()  
                # finally:
                        # print("OKKKKKKKKKKKKKKK")
                # connection.commit()
                # connection.close()
                # print("YETYY")                                      
                # from inde import Menuoption
                # objm=Menuoption("sarvesh")
                # objm.mainmenufun()
                
        def Order(self):
                print("ORDER SECTION")
                while True:
                        import mysql.connector
                        connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                        cursor1 = connection.cursor()
                        # print("1]Macdee\n2]BurgerKing\n3]Naturals")
                        query='select distinct brandname from menucard'
                        cursor1.execute(query)
                        result=cursor1.fetchall()
                        # print(result)
                        n = 1
                        brandnamelist = []
                        for i in result:
                                brandnamelist.append(i[0])  # Extracting the brand name from the tuple
                                print(n, " ", i[0])
                                n += 1

                # Get user input for brand name
                
                        br = input("Enter No To oreder from respective:\nPress Q for back  ")
                        if br=="q" or br=="Q":
                                break

                # Construct the SQL query based on user input
                        elif br.isdigit() and 1 <= int(br) <= len(brandnamelist):
                                selected_brand = brandnamelist[int(br) - 1]
                                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                cursor1 = connection.cursor()
                                query = f'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname = %s'
                                import warnings

                                # Suppress UserWarning from pandas
                                warnings.filterwarnings("ignore", category=UserWarning)

        # Your existing code
                                df = pd.read_sql_query(query, connection, params=(selected_brand,))
                                # df = pd.read_sql_query(query, connection, params=(selected_brand,))
                                 # Add a serial number column to the DataFrame
                                # df['Serial No'] = range(1, len(df) + 1)
                                df.insert(0, 'Serial No', range(1, len(df) + 1))
                                print(tabulate(df, headers='keys', tablefmt='pretty', showindex=False))
                                # Store DataFrame records in a list
                                # data_list = df.to_dict(orient='records')
                                # print("*"*20)
                                # print("Data List:", data_list)
                                
# Extract the 'productname' column and store it in a list
                                product_list = df['productname'].tolist()
                                # print("Product List:", product_list)
                                
                                while True:

                                
                                        ch=input("Enter respective no To Order Menu(Press Q to Go back)")
                                        if ch=="Q" or ch=="q":
                                                break
                                        elif ch.isdigit() and 1 <= int(ch) <= len(product_list):
                                                # pass
                                        # else:
                                                orderedmenu=product_list[int(ch)-1]
                                                print(orderedmenu)
                                                try:
                                                        quantity = int(input(f"How many {orderedmenu} do you want to order? "))
                                                except:
                                                        print("Enter valus in interger")
                                                        quantity=1
                                                # finally:
                                                        # quantity=1
                                                
                                                while True:
                                                        size = input("Enter the size (R/M/L): ").upper()
                                                        if size not in("r","R","m","M","l","L"):
                                                                print("ENter Size properlly")
                                                        else:
                                                                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                                                cursor1 = connection.cursor()
                                                                query = 'SELECT price{0} FROM menucard WHERE brandname = %s AND productname = %s'.format(size)
                                                                cursor1.execute(query, (selected_brand, orderedmenu))
                                                                price = cursor1.fetchone()[0]
                                                                # print(price)
                                                                total_price=price*int(quantity)
                                                                
                                                                # def saveord_to_db():
                                                                # try:
                                                                # create_table_order_details='''
                                                                #   CREATE TABLE Order_details (
                                                                #         lusername VARCHAR(50),
                                                                #         selected_brand VARCHAR(50),
                                                                #         orderedmenu VARCHAR(30),
                                                                #         size VARCHAR(30),
                                                                #         quantity INT,
                                                                #         total_prize INT,  -- Corrected column name
                                                                #         prize INT,
                                                                #         ordertime DATETIME
                                                                #         );

                                                                # #         '''
                                                                        
                                                                try:
                                                                        loginusername=lslogin[0]
                                                                        # print(loginusername)
                                                                        # Insert order details into the OrderDetails table
                                                                        connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                                                        cursor1 = connection.cursor()
                                                                        insert_query = "INSERT INTO order_details (lusername,selected_brand ,orderedmenu, size, quantity,prise, total_prise,ordertime) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
                                                                        cursor1.execute(insert_query, (loginusername,selected_brand, orderedmenu, size, int(quantity), price,total_price,formatted_datetime))
                                                                        connection.commit()
                                                                        print(f"_  {orderedmenu} Orderd Succesfully")
                                                                except Exception as e:
                                                                        # self.connection.rollback()
                                                                        print("Error saving order details to the database")
                                                                break
                                                        # return self.total_price
                                        else:
                                                print("please Enter proper no:")

                                # print(df)
                        else:
                                print("Invalid input or brand number out of range.")

                        # Close the database connection
                        connection.close()
        
        def Bill(self):
                print("BIll section")
                loginusername=lslogin[0]
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()
                bill_Query='Select orderedmenu,size,quantity,prise,total_prise from order_details where   payment_status is null and lusername=%s '
                cursor1.execute(bill_Query,(loginusername,))     
                result=cursor1.fetchall()
                
                # for i in result:
                #         print(i)
                # connection.commit()
                # print("This is your bill")
                header=['Menu','size','Quantity','prise','prise*Quantity']
                billlist=[]
                Sum_OF_Order_add=0
                for row in result:
                        Sum_OF_Order.append(row[4])
                        Sum_OF_Order_add+=row[4]
                        
                        
                        # print(f"{row[0]}\t{row[1]}\t{row[2]}\t{row[3]}\t{row[4]}\t{row[5]}")
                        billlist.append([row[0],row[1],row[2],row[3],row[4]])
                        
                displaytable=tabulate(billlist,header,tablefmt="pretty")
                print(displaytable)
                # # total_price
                # connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                # cursor1 = connection.cursor()
                # sum_query = f"SELECT SUM({self.total_price}) FROM Order_details"
                # cursor1.execute(sum_query)
                # dis_sum=cursor1.fetchall()
                print("YOUR Total BILL is "," "*10,Sum_OF_Order_add)
                print("1]Order more items\n2]Cancle Item from order\n3]Pay bill\n4]BAck")
                ch=input("ENter Your choise:")
                if ch=="1":
                        tabclassobj=TABLE()
                        tabclassobj.Order()
                elif ch=="2":
                        tabclassobj=TABLE()
                        tabclassobj.cancle_from_order()
                elif ch=="3":
                        print("PAY BILL section")
                        if Sum_OF_Order_add>1000:
                                print("Your bill is more than 1000 you ge discount of 12% ")
                                discount_1000=Sum_OF_Order_add/100*12
                                Total_bill=Sum_OF_Order_add-discount_1000
                                print("YOUR Total BILL is "," "*10,Sum_OF_Order_add)
                                print(f"You get discount of {discount_1000} ")
                                print(f"Total bill is{Total_bill}")
                                ch=input("Do You have coupen code?")
                                if ch=="yes" or ch== "y" or ch=="YES" :
                                        enter_coupen=input("Enter coupen code")
                                        # lpass=input("Enter password")
                                        connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                        cursor = connection.cursor()
                                        query = "SELECT coupen_code  FROM userrecord WHERE username =%s AND coupen_use is null and coupen_code=%s"
                                        cursor.execute(query, (loginusername,enter_coupen))
                                        is_eter_coupen = cursor.fetchone()
                                        
                                        connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                        cursor = connection.cursor()
                                        query = "SELECT After_coupen  FROM userrecord WHERE username =%s AND after_coupen_use is null and After_coupen=%s"
                                        cursor.execute(query, (loginusername,enter_coupen))
                                        is_after_eter_coupen = cursor.fetchone()
                                        print(is_eter_coupen)
                                        if is_eter_coupen or is_after_eter_coupen:
                                                print("Yes fetching")
                                                # if Sum_OF_Order_add>1000:
                                                #         print("Your bill is more than 1000 you ge discount of 12% ")
                                                #         discount_1000=Sum_OF_Order_add/100*12
                                                #         Total_bill=Sum_OF_Order_add-discount_1000
                                                #         print(f"You get discount of {discount_1000} ")
                                                        
                                                first_order_discount=Sum_OF_Order_add/100*20
                                                Total_bill=Sum_OF_Order_add-first_order_discount
                                                print(f"You get Discount of {first_order_discount}")
                                                print(f"Your total bill is {int(Total_bill)}")
                                                
                                                while True:
                                                        billpayment=float(input("Enter Amount to pay:"))
                                                        
                                                        if billpayment==int(Total_bill):
                                                                print("BILl Payed succusefully")
                                                                # Update the payment status to 'paid'
                                                                connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                                                cursor1 = connection.cursor()
                                                                update_payment_query = '''UPDATE Order_details SET payment_status = 'paid' WHERE lusername=%s and payment_status is null '''
                                                                cursor1.execute(update_payment_query, (loginusername,))
                                                                connection.commit()
                                                                print("Payment successful. Thank you!")
                                                                
                                                                connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')

                                                                cursor1 = connection.cursor()
                                                                update_payment_query = '''UPDATE userrecord SET coupen_use = 'use' WHERE username=%s and coupen_use is null '''
                                                                cursor1.execute(update_payment_query, (loginusername,))
                                                                connection.commit()
                                                                # if Total_bill>2000:
                                                                #         import random as rd
                                                                #         characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                                                                #         coupen_code_2000=''.join(rd.choice(characters) for i in range(6))
                                                                #         print("Thank You for Join US")
                                                                #         print("You get Coupen code of '18%' for puchesing over 2000 you can use it once")
                                                                #         print(f"This is Your coupen_code   | {coupen_code_2000} |")
                                                                #         connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                                                #         # Create a cursor object
                                                                #         cursor1 = connection.cursor()
                                                                #         # Define the SQL command with placeholders for user input
                                                                #         update_sql = "UPDATE userrecord SET After_coupen =%s  WHERE username = %s"
                                                                #         cursor1.execute(update_sql, ("usee", loginusername))

                                                                        
                                                                #         connection.commit()
                                                                #         print("qwer")
                                                                #         connection.close()
                                                                        
                                                                
                                                                
                                                                from inde import Home
                                                                objhome=Home()
                                                                objhome.home()
                                                        else:
                                                                print("payment fail..")
                                        else:
                                                print("YOU entered wrong Coupen code Or This coupen is allready used")        
                                        # pass
                                elif ch=="no":
                                      
                                                        first_order_discount=Sum_OF_Order_add/100*20
                                                        Total_bill=Sum_OF_Order_add-first_order_discount
                                                        print(f"You get Discount of {first_order_discount}")
                                                        print(f"Your total bill is {int(Total_bill)}")
                                                        billpayment=int(input("Enter Amount to pay:"))
                                                        if billpayment==int(Total_bill):
                                                                print("BILl Payed succusefully")
                                                                # Update the payment status to 'paid'
                                                                update_payment_query = '''UPDATE Order_details SET payment_status = 'paid' WHERE lusername=%s and payment_status is null '''
                                                                cursor1.execute(update_payment_query, (loginusername,))
                                                                connection.commit()
                                                                print("Payment successful. Thank you!")
                                                                # if Total_bill>2000:
                                                                #         import random as rd
                                                                #         characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                                                                #         coupen_code_2000=''.join(rd.choice(characters) for i in range(6))
                                                                #         print("Thank You for Join US")
                                                                #         print("You get Coupen code of '18%' for puchesing over 2000 you can use it once")
                                                                #         print(f"This is Your coupen_code   | {coupen_code_2000} |")
                                                                #         connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                                                #         # Create a cursor object
                                                                #         cursor1 = connection.cursor()
                                                                #         # Define the SQL command with placeholders for user input
                                                                #         update_sql = "UPDATE userrecord SET After_coupen = %s WHERE username = %s"
                                                                #         cursor1.execute(update_sql, (coupen_code_2000, loginusername))
                                                           
                                                                #         connection.commit()
                                                                #         print("12345")
                                                                #         connection.close()
                                                                from inde import Home
                                                                objhome=Home()
                                                                objhome.home()
                        else:   
                                print("Get discount of 20%"+"for new users")
                                ch=input("Do You have coupen code?")
                                if ch=="yes" or ch== "y" or ch=="YES" :
                                        enter_coupen=input("Enter coupen code")
                                        # lpass=input("Enter password")
                                        connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                        cursor = connection.cursor()
                                        query = "SELECT coupen_code FROM userrecord WHERE username =%s AND coupen_use is null"
                                        cursor.execute(query, (loginusername,))
                                        is_eter_coupen = cursor.fetchone()
                                        print(is_eter_coupen)
                                        
                                        connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                        cursor = connection.cursor()
                                        query = "SELECT After_coupen  FROM userrecord WHERE username =%s AND after_coupen_use is null and After_coupen=%s"
                                        cursor.execute(query, (loginusername,enter_coupen))
                                        is_after_eter_coupen = cursor.fetchone()
                                        print(is_eter_coupen)
                                        if is_eter_coupen or is_after_eter_coupen:
                                        
                                                print("Yes fetching")
                                                # if Sum_OF_Order_add>1000:
                                                #         print("Your bill is more than 1000 you ge discount of 12% ")
                                                #         discount_1000=Sum_OF_Order_add/100*12
                                                #         Total_bill=Sum_OF_Order_add-discount_1000
                                                #         print(f"You get discount of {discount_1000} ")
                                                        
                                                first_order_discount=Sum_OF_Order_add/100*20
                                                Total_bill=Sum_OF_Order_add-first_order_discount
                                                print(f"You get Discount of {first_order_discount}")
                                                print(f"Your total bill is {Total_bill}")
                                                billpayment=float(input("Enter Amount to pay:"))
                                                if billpayment==Total_bill:
                                                        print("BILl Payed succusefully")
                                                        # Update the payment status to 'paid'
                                                        update_payment_query = '''UPDATE Order_details SET payment_status = 'paid' WHERE lusername=%s and payment_status is null '''
                                                        cursor1.execute(update_payment_query, (loginusername,))
                                                        connection.commit()
                                                        print("Payment successful. Thank you!")
                                                        # if Total_bill>2000:
                                                        #                 import random as rd
                                                        #                 characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                                                        #                 coupen_code_2000=''.join(rd.choice(characters) for i in range(6))
                                                        #                 print("Thank You for Join US")
                                                        #                 print("You get Coupen code of '18%' for puchesing over 2000 you can use it once")
                                                        #                 print(f"This is Your coupen_code   | {coupen_code_2000} |")
                                                        #                 connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                                        #                 # Create a cursor object
                                                        #                 cursor1 = connection.cursor()
                                                        #                 # Define the SQL command with placeholders for user input
                                                        #                 insert_sql = "INSERT INTO userrecord (username, After_coupen) VALUES (%s, %s)"
                                                        #                 # Execute the SQL command with user input
                                                        #                 cursor1.execute(insert_sql, (loginusername,coupen_code_2000))
                                                        #                 connection.commit()
                                                        #                 connection.close()
                                                        
                                                        from inde import Home
                                                        objhome=Home()
                                                        objhome.home()               
                                elif ch=="no" or ch=="n" or ch=="No":
                                        print(f"Total Bill is  |{Sum_OF_Order_add}")
                                        billpayment=int(input("Enter Amount to pay:"))
                                        if billpayment==Sum_OF_Order_add:
                                                        print("BILl Payed succusefully")
                                                        # Update the payment status to 'paid'
                                                        update_payment_query = '''UPDATE Order_details SET payment_status = 'paid' WHERE lusername=%s and payment_status is null '''
                                                        cursor1.execute(update_payment_query, (loginusername,))
                                                        connection.commit()
                                                        print("Payment successful. Thank you!")
                                                        
                                                        from inde import Home
                                                        objhome=Home()
                                                        objhome.home() 
                                        
                elif ch=="4":
                        pass
                
        def cancle_from_order(self):
            # Establish the database connection
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()

                # Display the menu items for the user to choose from
                # query = 'SELECT * FROM menucard'
                # cursor1.execute(query)
                # result = cursor1.fetchall()
                loginusername=lslogin[0]
                # print(type(loginusername))
                bill_Query='Select orderedmenu,size,quantity,prise,total_prise from order_details where   payment_status is null and lusername=%s '
                cursor1.execute(bill_Query,(loginusername,))     
                result=cursor1.fetchall()

                if not result:
                        print("Bill is Empty. Nothing to cancle.")
                        connection.close()
                        return

                print("Your order Menu:")
                # print("ID\tBrand\tProduct\tPrice R\tPrice M\tPrice L")
                n=1
                
                for row in result:
                        lsoreredmenu.append(row[0])
                        print(f"{n}{row[0]}\t{row[1]}\t{row[2]}\t{row[3]}\t{row[4]}")
                        n+=1
                # Get the ID of the menu item to delete
                while True:
                        
                        order_id_to_delete = (input("Enter the ID of the ordermenu item you want to cancle:(press Q to go back) "))
                        if order_id_to_delete=="Q" or order_id_to_delete=="q":
                                break
                        # Check if the entered ID exists in the menu
                        else:
                                while True:
                                        updated_order_id_to_delete=lsoreredmenu[int(order_id_to_delete)-1]
                                        if int(order_id_to_delete)>len(lsoreredmenu):
                                                print("Invalid ID. Menu item not found.")
                                                break
                                        else:
                                        # Delete the menu item
                                                # ch=input("DO You Want TO remo ")
                                                # print("1]To remove an Item\n]Reduse quntity")
                                                # print("Enter Your Choise")
                                                # if ch=="1":

                                                                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                                                cursor1 = connection.cursor()
                                                                delete_from_menucard_query = "DELETE FROM order_details WHERE orderedmenu = %s and lusername=%s and payment_status is null"
                                                                cursor1.execute(delete_from_menucard_query, (updated_order_id_to_delete,loginusername))
                                                                connection.commit()
                                                                print("Ordermenu deleted successfully.")
                                                                tabclassobj=TABLE()
                                                                tabclassobj.Bill()

                                                        # Close the cursor and connection
                                                                cursor1.close()
                                                                connection.close()
                                               
                                                        
                
                
        def addintomenucard(self):
                
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()

                # print("1]Macdee\n2]BurgerKing\n3]Naturals")
                query='select distinct brandname from menucard'
                cursor1.execute(query)
                result=cursor1.fetchall()
                # print(result)
                n = 1
                brandnamelist = []
                for i in result:
                        brandnamelist.append(i[0])  # Extracting the brand name from the tuple
                        print(n, " ", i[0])
                        n += 1
                
                
                # print("in which Brand do You want to add a product:/n1]McD\n2]Burgerking\n3]Naturals\n4]KFC /n 5] press any key to add new brand")
                ch=input("Enter your choise:  Enter 1 if you want to add product in above brand or:press any key to add new brand")
                if ch=="1":
                        while True:
                                brandname=input("Enter brandname you want to add product IN \n OR Enter stop For STOP Inserting")
                                
                                if brandname=="Stop":
                                        break
                #         brandname="McDonold"
                # elif ch=="2":
                #         brandname="BurgerKing"
                # elif ch=="3":
                #         brandname="Naturals"
                # elif ch=="4":
                #         brandname=="KFC"
                else:
                        brandname=input("Enter new brandname you want to add")
                productname=input("Enter Product name you want to add")
                priceR=int(input("Enter Price for R:"))     
                priceM=int(input("Enter Price for M:"))        
                priceL=int(input("Enter Price for L:"))        
        
                
                
                
                
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1=connection.cursor()
                # insert_to_menucard="""  insert into table menucard"""
                insert_to_menucard = "INSERT INTO menucard (brandname, productname, priceR,priceM,priceL) VALUES (%s, %s, %s, %s,%s)"
                cursor1.execute(insert_to_menucard,(brandname, productname, priceR,priceM,priceL))
                connection.commit()
                connection.close()
                print("Inserted Succesfully")
                
                
        # import mysql.connector

 

        def delete_from_menucard(self):
        # Establish the database connection
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()

                # Display the menu items for the user to choose from
                query = 'SELECT * FROM menucard'
                cursor1.execute(query)
                result = cursor1.fetchall()

                if not result:
                        print("Menu is empty. Nothing to delete.")
                        connection.close()
                        return

                print("Current Menu:")
                print("ID\tBrand\tProduct\tPrice R\tPrice M\tPrice L")
                for row in result:
                        print(f"{row[0]}\t{row[1]}\t{row[2]}\t{row[3]}\t{row[4]}\t{row[5]}")

                # Get the ID of the menu item to delete
                while True:
                        
                        menu_id_to_delete = (input("Enter the ID of the menu item you want to delete:(press Q to go back) "))
                        if menu_id_to_delete=="Q" or menu_id_to_delete=="q":
                                break
                        # Check if the entered ID exists in the menu
                        elif int(menu_id_to_delete) not in [row[0] for row in result]:
                                print("Invalid ID. Menu item not found.")
                        else:
                        # Delete the menu item
                                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                cursor1 = connection.cursor()
                                delete_from_menucard_query = "DELETE FROM menucard WHERE id = %s"
                                cursor1.execute(delete_from_menucard_query, (int(menu_id_to_delete),))
                                connection.commit()
                                print("Menu item deleted successfully.")

                        # Close the cursor and connection
                        cursor1.close()
                        connection.close()

        

        def update_menu_prices(self):
                # Establish the database connection
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()

                # Display the menu items for the user to choose from
                query = 'SELECT * FROM menucard'
                cursor1.execute(query)
                result = cursor1.fetchall()

                if not result:
                        print("Menu is empty. Nothing to update.")
                        connection.close()
                        return

                print("Current Menu:")
                print("ID\tBrand\tProduct\tPrice R\tPrice M\tPrice L")
                header=["ID","Brand","Product","PriceR","Price M","Price L"]
                update_table_data=[]
                for row in result:
                        # print(f"{row[0]}\t{row[1]}\t{row[2]}\t{row[3]}\t{row[4]}\t{row[5]}")
                        update_table_data.append([row[0],row[1],row[2],row[3],row[4],row[5]])
                        
                displaytable=tabulate(update_table_data,header,tablefmt="pretty")
                print(displaytable)
                while True:
                # Get the ID of the menu item to update
                        menu_id_to_update = (input("Enter the ID of the menu item you want to update: "))
                        if menu_id_to_update=="q" or menu_id_to_update=="Q":
                                break
                        # Check if the entered ID exists in the menu
                        elif int(menu_id_to_update) not in [row[0] for row in result]:
                                print("Invalid ID. Menu item not found.")
                        else:
                        # Get the new prices
                                new_priceR = int(input("Enter the new price for R: "))
                                new_priceM = int(input("Enter the new price for M: "))
                                new_priceL = int(input("Enter the new price for L: "))

                        # Update the menu item with the new prices
                                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                cursor1 = connection.cursor()
                                update_menu_prices_query = "UPDATE menucard SET priceR = %s, priceM = %s, priceL = %s WHERE id = %s"
                                cursor1.execute(update_menu_prices_query, (new_priceR, new_priceM, new_priceL, int(menu_id_to_update)))
                                connection.commit()
                                print("Menu item prices updated successfully.")

                        # Close the cursor and connection
                        cursor1.close()
                        connection.close()

        # Example usage:
# your_instance = YourClass()
# your_instance.update_menu_prices()

        def Graphics(self):
                print("1]Age group\n]Brand uses \n3]")
                ch=input("Enter choise")
                if ch=="1":
                        connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                        cursor1 = connection.cursor()
                        age_grafic_query = "select age from userrecord"
                        cursor1.execute(age_grafic_query)
                        agels=[]
                        result=cursor1.fetchall()
                        for i in result:
                                agels.append(i)
                        
                        connection.commit()
                        print()  
                        # age=["10-20","21-30","31-40","40-50","50+"]
                        
                                        
                                
                        
                        

                                
                                
                        
                        # import matplotlib.pyplot as plt

        # Your list of data
                        # data = agels

                        # Define the decades
                        # decades = [10, 20, 30, 40, 50]

                        # Initialize an empty list to store the counts
                        # decade_counts = []

                        # Loop through the decades
                        # for decade in decades:
                        #         count = sum(1 for age in data if decade <= age < decade + 10)
                        # decade_counts.append(count)

                        # # Create a bar chart
                        # plt.bar(decades, decade_counts, width=8, color='blue', edgecolor='black')

                        # # Add labels and title
                        # plt.xlabel('age group')
                        # plt.ylabel('Count')
                        # plt.title('Distribution of Data by age group')

                        # # Show the plot
                        # plt.show()
                elif ch=="2":
                        connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                        cursor1 = connection.cursor()
                        age_grafic_query = "select selected_brand from order_details"
                        cursor1.execute(age_grafic_query)
                        ls_brand=[]
                        result=cursor1.fetchall()
                        for i in result:
                                ls_brand.append(i)
                        # Your list of brand names

                        brand_counts = {}

                        # Iterate through the list and count occurrences
                        for brand in ls_brand:
                                if brand in brand_counts:
                                        brand_counts[brand] += 1
                                else:
                                        brand_counts[brand] = 1

                                # Print the dictionary
                        print(brand_counts)
                        keys_list = [brand[0] for brand in brand_counts.keys()]
                        values_list = list(brand_counts.values())
                        import matplotlib.pyplot as plt

# Given lists
# keys_list = ['McDonold', 'KFC', 'BurgerKing', 'NaadBrahma', 'Gupta sandwitch', 'Raigad Vadapav']
# values_list = [45, 26, 22, 1, 9, 13]

# Create a bar chart
                        plt.bar(keys_list, values_list, color='blue', edgecolor='black')

                        # Add labels and title
                        plt.xlabel('Brand Names')
                        plt.ylabel('Count')
                        plt.title('Brand Counts')

                        # Show the plot
                        plt.show()


                                
                        
                        
                        connection.commit()
                        print()
                        
        def userrecordshow(self):
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1=connection.cursor()
                userrecord_show = "select * from userrecord"
                cursor1.execute(userrecord_show)
                # ls_brand=[]
                result=cursor1.fetchall()
                for i in result:
                        print(i)
                column_names = [desc[0] for desc in cursor1.description]

# Display the result using tabulate
                print(tabulate(result, headers=column_names, tablefmt="pretty"))
                
                     
        def table_creation(self):
                #creating database
                try:
                        connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                        cursor1=connection.cursor()
                        database_name="project"
                        create_database_query = f"CREATE DATABASE {database_name}"
        # cursor.execute(create_database_query)
                        
                        cursor1.execute(create_database_query)
                        connection.commit()
                        print("DATABASE  created")
                        
                        connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                        cursor1=connection.cursor()
                except:
                        print("Database  allready Exist")
                #ADMIN TABLE
                try:
                        create_table_admin = '''
                                        CREATE TABLE admin (
                                                adminname VARCHAR(20) PRIMARY KEY,
                                                adminpass VARCHAR(6)
                                        )
                                        '''

                        cursor1.execute(create_table_admin)
                        connection.commit()
                        print("Admin table created")
                except:
                        print(" Admin Table allready exist")
                        
                try:    #ADMIN DETAILS INSERT
                        insert_data = '''  INSERT INTO admin (adminname, adminpass) VALUES (%s, %s)'''
                        adminname="sarvesh"
                        adminpass="sarsha"
                        admin_data = (adminname, adminpass)  
                        cursor1.execute(insert_data, admin_data)
                        connection.commit()
                        print("Insert Succsesfully")
                except:
                        print("admin record allready exist")
                
                
                
                
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1=connection.cursor()
                # Order_details table
                try:
                        create_table_admin ='''
                        CREATE TABLE Order_details (
                        lusername varchar(50),
                        selected_brand varchar(50),
                        orderedmenu varchar(30),
                        size varchar(30),
                        quantity int,
                        prise int,
                        total_prise int,
                        ordertime datetime,
                        payment_status varchar(20),
                        After_coupen varchar(6),
                        after_coupen_use varchar(10)
                        );'''



                        cursor1.execute(create_table_admin)
                        connection.commit()
                        print(" Order details table created")
                except:
                        print("  Order Table allready exist")
                # create_table_Userrecord
                try:
                        create_table_Userrecord='''
                       CREATE TABLE userrecord (
                        username varchar(30) NOT NULL,
                        name varchar(255),
                        age int,
                        pass1 varchar(4),
                        coupen_code varchar(6),
                        coupen_use varchar(3),
                        After_coupen varchar(6),
                        after_coupen_use varchar(10)
                        PRIMARY KEY (username)
                        );
                        '''


                        cursor1.execute(create_table_Userrecord)
                        connection.commit()
                        print(" userrecord table created")
                except:
                        print(" userrecord Table allready exist")
                     
                #create table menucard
                try:         
                        create_table_menucard='''
                       CREATE TABLE menucard (
                        id int NOT NULL PRIMARY KEY AUTO_INCREMENT,
                        brandname varchar(255),
                        productname varchar(255),
                        priceR int,
                        priceM int,
                        priceL int
                        );

                        '''
                        cursor1.execute(create_table_menucard)
                        connection.commit()
                        print(" menucard table created")
                except:
                        print(" menucard Table allready exist")
                        
                #insert data in menucard
                try:
                        insert_data_in_menucard = ''' INSERT INTO menucard (brandname, productname, priceR, priceM, priceL) VALUES
                                ('McDonold', 'McD Spe. Meal', 12, 12, 12),
                                ('McDonold', 'Burger', 179, 209, 239),
                                ('McDonold', 'French Fries', 90, 100, 110),
                                ('McDonold', 'McChicken Burger', 119, 139, 159),
                                ('McDonold', 'McSpicy Paneer Burger', 179, 199, 209),
                                ('BurgerKing', 'Special meal', 230, 250, 280),
                                ('McDonold', 'MacCHICKEN', 250, 250, 250),
                                ('McDonold', 'Chicken Nuggets Bucket', 420, 430, 450),
                                ('BurgerKing', 'Crispy veg burgur', 69, 89, 99),
                                ('BurgerKing', 'Royal Classic Burger', 239, 269, 299),
                                ('BurgerKing', 'Whopper Supreme Delight', 299, 329, 349),
                                ('BurgerKing', 'Chicken Fries (6 pieces)', 180, 290, 320),
                                ('Gupta sandwitch', 'gupta Spe.sandwitch', 60, 70, 80),
                                ('BurgerKing', 'whooper', 200, 230, 269),
                                ('Gupta sandwitch', 'chees sandwitch', 89, 99, 124),
                                ('KFC', 'Bucket chiken', 350, 400, 420),
                                ('KFC', 'KFC Zinger Combo', 299, 299, 299),
                                ('KFC', 'KFC Family Bucket', 599, 699, 899),
                                ('SuperFastFood', 'vadapaV', 15, 15, 15),
                                ('starbuck', 'cofee', 100, 150, 200);
                                '''
                        cursor1.execute(insert_data_in_menucard)
                        connection.commit()
                        print("Menu card record Insert Succsesfully")
                except:
                        print("MenuCard record allready exist")
                        
                        
                        
                        
                
                        


                      
                        
                