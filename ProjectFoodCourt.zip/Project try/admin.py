import tables
class Admin:
    
    def Addproduct(self):
        pass

        print("1]Add product\n2]Change prize\n3]view Insights\n4]View User")
        self.ch=input("Enter Your choise")
        if self.ch=="1":
            tables.addintomenucard()
            
    