summ=200
first_order_discount=summ/100*20
print(first_order_discount)








print("in which Brand do You want to add a product:\n1]McD\n2]Burgerking\n3]Naturals\n4]KFC")
print("Enter your choise")

import pandas as pd





def menucard(self):
                # self.sss=sss
                # print("in which Brand do You want to add a product:/n1]McD/n2]Burgerking/n3]Naturals/n4]KFC")
                # print("Enter your choise")
                '''connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()
                create_table_menucard = """
                        CREATE TABLE IF NOT EXISTS menucard (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        brandname VARCHAR(255),
                        productname varchar(255),
                        priceR int,
                        priceM int,
                        priceL int
                        )
                        """    
                create_table_order="""
                 
                # try:
        
                # cursor1.execute(create_table_menucard)
                        
                        # print("table created")
                
                        # ("Table allready exist")'''
                import mysql.connector
# import pandas as pd

                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()

                # print("1]Macdee\n2]BurgerKing\n3]Naturals")
                query='select distinct brandname from menucard'
                cursor1.execute(query)
                result=cursor1.fetchall()
                # print(result)
                n = 1
                brandnamelist = []
                for i in result:
                        brandnamelist.append(i[0])  # Extracting the brand name from the tuple
                        print(n, " ", i[0])
                        n += 1

                # Get user input for brand name
                while True:
                        br = input("Enter No To view menu:\nPress Q for back  ")

                # Construct the SQL query based on user input
                        if br.isdigit() and 1 <= int(br) <= len(brandnamelist):
                                selected_brand = brandnamelist[int(br) - 1]
                                query = f'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname = %s'
                                import warnings

                                # Suppress UserWarning from pandas
                                warnings.filterwarnings("ignore", category=UserWarning)

        # Your existing code
                                df = pd.read_sql_query(query, connection, params=(selected_brand,))
                                # df = pd.read_sql_query(query, connection, params=(selected_brand,))
                                 # Add a serial number column to the DataFrame
                                # df['Serial No'] = range(1, len(df) + 1)
                                df.insert(0, 'Serial No', range(1, len(df) + 1))
                                print(tabulate(df, headers='keys', tablefmt='pretty', showindex=False))

                                # print(df)
                        else:
                                print("Invalid input or brand number out of range.")

                        # Close the database connection
                        connection.close()




import mysql.connector
import pandas as pd
from tabulate import tabulate  # You need to install the tabulate library for this

class MenuCard:
    def __init__(self):
        self.connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
        self.cursor = self.connection.cursor()

    def menu_card(self):
        query = 'select distinct brandname from menucard'
        self.cursor.execute(query)
        result = self.cursor.fetchall()
        n = 1
        brand_name_list = []
        for i in result:
            brand_name_list.append(i[0])
            print(n, i[0])
            n += 1

        while True:
            user_input = input("Enter the number to view the menu:\nPress Q to go back: ")

            if user_input.isdigit() and 1 <= int(user_input) <= len(brand_name_list):
                selected_brand = brand_name_list[int(user_input) - 1]
                query = 'SELECT productname, priceR, priceM, priceL FROM menucard WHERE brandname = %s'
                df = pd.read_sql_query(query, self.connection, params=(selected_brand,))
                print(tabulate(df, headers='keys', tablefmt='pretty', showindex=False))

                order_product = input("Enter the product name to order (Press Q to go back): ")
                if order_product.upper() == 'Q':
                    break
                else:
                        
                    self.place_order(selected_brand, order_product)
            elif user_input.upper() == 'Q':
                break
            else:
                print("Invalid input or brand number out of range.")

    def place_order(self, brand, product):
        quantity = int(input(f"How many {product} do you want to order? "))
        size = input("Enter the size (R/M/L): ").upper()

        # Get the price of the selected product and size
        query = 'SELECT price{0} FROM menucard WHERE brandname = %s AND productname = %s'.format(size)
        self.cursor.execute(query, (brand, product))
        price = self.cursor.fetchone()[0]

        # Calculate the total price
        total_price = quantity * price

        print(f"\nOrder Summary:")
        print(f"Brand: {brand}")
        print(f"Product: {product}")
        print(f"Size: {size}")
        print(f"Quantity: {quantity}")
        print(f"Total Price: ₹{total_price}")

        # You can add more logic to save the order to a database or display additional information


# menu_card_instance = MenuCard()
# menu_card_instance.menu_card()


# import datetime as dt

from datetime import datetime

# Get the current date and time
current_datetime = datetime.now()

# Print the current date and time
print("Current Date and Time:", current_datetime)
print("*"*23)

from datetime import datetime

# Get the current date and time
current_datetime = datetime.now()

# Format the date and time as a string
formatted_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")

# Print the formatted date and time
print("Formatted Date and Time:", formatted_datetime)

import random as rd

characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
coupen_code=''.join(rd.choice(characters) for i in range(7))
print(coupen_code)

def cancle_from_order(self):
            # Establish the database connection
                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                cursor1 = connection.cursor()

                # Display the menu items for the user to choose from
                # query = 'SELECT * FROM menucard'
                # cursor1.execute(query)
                # result = cursor1.fetchall()
                bill_Query='Select orderedmenu,size,quantity,prise,total_prise from order_details where   payment_status is null and lusername=%s '
                cursor1.execute(bill_Query,(loginusername,))     
                result=cursor1.fetchall()

                if not result:
                        print("Bill is Empty. Nothing to cancle.")
                        connection.close()
                        return

                print("Your order Menu:")
                print("ID\tBrand\tProduct\tPrice R\tPrice M\tPrice L")
                # n=1
                for row in result:
                        print(f"{row[0]}\t{row[1]}\t{row[2]}\t{row[3]}\t{row[4]}\t{row[5]}")
                        # n+=1
                # Get the ID of the menu item to delete
                while True:
                        
                        order_id_to_delete = (input("Enter the ID of the menu item you want to delete:(press Q to go back) "))
                        if order_id_to_delete=="Q" or order_id_to_delete=="q":
                                break
                        # Check if the entered ID exists in the menu
                        elif int(order_id_to_delete) not in [row[0] for row in result]:
                                print("Invalid ID. Menu item not found.")
                        else:
                        # Delete the menu item
                                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                cursor1 = connection.cursor()
                                delete_from_menucard_query = "DELETE FROM order_details WHERE id = %s and lusername=%s and payment_status is null"
                                cursor1.execute(delete_from_menucard_query, (int(order_id_to_delete),listoflusername))
                                connection.commit()
                                print("Ordermenu deleted successfully.")

                        # Close the cursor and connection
                        cursor1.close()
                        connection.close()