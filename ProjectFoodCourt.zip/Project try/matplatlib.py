# import matplotlib.pyplot as plt

# # Given lists
# keys_list = ['McDonold', 'KFC', 'BurgerKing', 'NaadBrahma', 'Gupta sandwitch', 'Raigad Vadapav']
# values_list = [45, 26, 22, 1, 9, 13]

# # Create a bar chart
# plt.bar(keys_list, values_list, color='blue', edgecolor='black')

# # Add labels and title
# plt.xlabel('Brand Names')
# plt.ylabel('Count')
# plt.title('Brand Counts')

# # Show the plot
# plt.show()



agedata={}
                        # age = ["10-20", "21-30", "31-40", "40-50", "50+"]
# agedata = {}
agels=[12,12,34,44,55,33,22,23,12,34,43,52]
# Initialize each key in agedata with an initial value (e.g., 0)
for i in agels:
        agedata[i] = 0

                        # # Example: Display the initialized agedata
                        # print("Initialized agedata:")
print(agedata)
                        
for age in agels:
        if 10 <= age <= 20:
            agedata["10-20"] += 1
        elif 21 <= age <= 30:
            agedata["21-30"] += 1
        elif 31 <= age <= 40:
            agedata["31-40"] += 1
        elif 41 <= age <= 50:
            agedata["41-50"] += 1
        elif age > 50:
            agedata["50+"] += 1

                                        
print(agedata)
