import mysql.connector
# import tables as tb
# import mainmenu as mn
# import mainmenu
from tabulate import tabulate 
import random as rd


#main menufile all conntent start

class Menuoption:
    def __init__(self,a):
        self.a=a
        # print(self.a)
    def mainmenufun(self):
        from tables import TABLE
        print()
        print("Press no in front of option:")
        print("\n1]Menu card\n2]Order\n3]Bill\n4]Home")

        ch=input("Enter Your Chois:")
        if ch=="1":
             
            tabclassobj=TABLE()
        #     tabclassobj.table_creation()
            
            tabclassobj.menucard()
        #     pass
        elif ch=="2":
                print("Order Section:")
                tabclassobj=TABLE()
                # glo=tabclassobj.Order()
                tabclassobj.Order()
        elif ch=="3":
                tabclassobj=TABLE()
                tabclassobj.Bill()
        elif ch=="4":
            objhome.home()
        else:
                print("Invalid INPUT")

#main menufile all conntent end

    
class Section:

        def adminsection(self):
                # while True:
                # adminname=input("Enter admin name:")
                while True:  
                                adminname=input("Enter admin name:")
                                connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                cursor = connection.cursor()
                # Check if the username already exists in the database
                                query = "SELECT adminname FROM admin WHERE adminname = %s"
                                cursor.execute(query, (adminname,))
                                is_exist = cursor.fetchone()
                                if is_exist:
                                         while True:
                                                apass=input("Enter password")
                                                connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                                cursor = connection.cursor()
                                                query = "SELECT adminpass FROM admin WHERE adminpass =%s "
                                                cursor.execute(query, (apass,))
                                                is_pass = cursor.fetchone()
                                                if is_pass:
                                                        print(" _"*10 + "\n| AdminLog in successful |\n" + " _"*10)

                                                        while True:

                                                                vv=input("Press Any Key to Conutinu")
                                                                # if vv=="Q":
                                                                        # objhome.objhome.home()
                                                                if vv!="qajhfkadfbkadfbdahf":
                                                                        
                                                                        # from tables import TABLE
                 
                
                                                                        print("1]Add product\n2]Delete Product \n3]Change prize\n4]view Insights\n5]View User\n6]Home")
                                                                        ch=input("Enter Your choise")
                                                                        if ch=="1":# ADD product
                                                                                while True:
                                                                                        insag=input("Prese Q to stop inserting Or Press Any key to countinuw")
                                                                                        if insag=="q" or insag=="Q":
                                                                                                objhome.objhome.home()
                                                                                                # break
                                                                                        else:
                                                                                                from tables import TABLE
                                                                                                tabclassobj=TABLE()
                                                
                                                                                                tabclassobj.addintomenucard()
                                                                        elif ch=="2":#FOr delete product
                                                                                print("Delete product section")
                                                                                while True:
                                                                                        insag=input("Prese Q to stop Deleting Or Press Any key to countinuw")
                                                                                        if insag=="q" or insag=="Q":
                                                                                                break
                                                                                        else:
                                                                                                from tables import TABLE
                                                                                                tabclassobj=TABLE()
                                                
                                                                                                tabclassobj.delete_from_menucard()
                                                                        elif ch=="3":#For update price
                                                                                print("Update prices  product section")
                                                                                while True:
                                                                                        insag=input("Prese Q to stop Updating Or Press Any key to countinuw")
                                                                                        if insag=="q" or insag=="Q":
                                                                                                break
                                                                                        else:
                                                                                                from tables import TABLE
                                                                                                tabclassobj=TABLE()
                                                                                                tabclassobj.update_menu_prices()
                                                                        elif ch=="4":# View Insights
                                                                                from tables import TABLE
                                                                                tabclassobj=TABLE()
                                                                                tabclassobj.Graphics()
                                                                        elif ch=="5":# view Users
                                                                                from tables import TABLE
                                                                                tabclassobj=TABLE()
                                                                                tabclassobj.userrecordshow()
                                                                        elif ch=="6":
                                                                                objhome.home()
                                                else:
                                                        print("YOU Enterd wrong password")
                                else:
                                        print("Admin name not Exist") 
        def reg(self):
                        while True:
                                name=input("Enter Your name:")
                                if name.isalpha():
                                        break
                                else:
                                        print("Name must in alpha characters")
                        while True:
                                try:
                                        age=int(input("Enter your age:"))

                                        if  (age>10 and age<90):
                                                break 
                                        else:  
                                                print("ENter valid age 10>> and <<90")      
                                
                                except ValueError:
                                        print("Enter age in Interger")
                        while True:  
                                username=input("set your user name:")       
                                connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                cursor = connection.cursor()
                # Check if the username already exists in the database
                                query = "SELECT username FROM userrecord WHERE username = %s"
                                cursor.execute(query, (username,))
                                result = cursor.fetchone()
                                if result:
                                        # return False  # Username is not unique
                                        # break
                                        print("This username is allready exist")
                                        # break
                                else:
                                        # return True  # Username is unique
                                        break
                        while True:                      
                                pass1=input("Set Password:")
                                if len(pass1)!=4:
                                        print("Password must be of 4 character")
                                        
                                # print("Acoount created sy")  
                                else:
                                        break
                        try:     
                                        def insertuser():
                                                # Connect to the MySQL server
                                                characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                                                coupen_code=''.join(rd.choice(characters) for i in range(6))
                                                print("Thank You for Join US")
                                                print("You get Coupen code of '20%' of ,You can use iy on your first order")
                                                print(f"This is Your coupen_code   | {coupen_code} |")
                                                connection = mysql.connector.connect(host='localhost', username='root', password='root123', database='project')
                                                # Create a cursor object
                                                cursor1 = connection.cursor()
                                                # Define the SQL command with placeholders for user input
                                                insert_sql = "INSERT INTO userrecord (username, name, age, pass1,coupen_code) VALUES (%s, %s, %s, %s,%s)"
                                                # Execute the SQL command with user input
                                                cursor1.execute(insert_sql, (username, name, age, pass1,coupen_code))
                                                connection.commit()
                                                connection.close()
                                                # print("Insert succsfully")
                                                print("Account created")
                                                
                                                # OBJsection.usersection()
                                                objhome.home()
                                        insertuser()
                        except mysql.connector.errors.IntegrityError as e:
                                        print(e)
                # elif ch=="2":
        def login(self):    
                        while True:  
                                lusername=input("Enter your username:")
                                connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                cursor = connection.cursor()
                # Check if the username already exists in the database
                                query = "SELECT username FROM userrecord WHERE username = %s"
                                cursor.execute(query, (lusername,))
                                is_exist = cursor.fetchone()
                                if is_exist:
                                        import tables as tb
                                        tb.lslogin.append(lusername)
                                        while True:
                                                lpass=input("Enter password")
                                                connection = mysql.connector.connect(host='localhost', user='root', password='root123', database='project')
                                                cursor = connection.cursor()
                                                query = "SELECT pass1 FROM userrecord WHERE pass1 =%s AND username =%s"
                                                cursor.execute(query, (lpass,lusername))
                                                is_pass = cursor.fetchone()
                                                # print(is_pass)
                                                if is_pass:
                                                        
                                                        # print("Log in Succseffully")
                                                        print(" _"*10 + "\n| Log in successful |\n" + " _"*10)

                                                        while True:

                                                                vv=input("Press Any Key to Conutinu")
                                                                if vv!="qajhfkadfbkadfbdahf":
                                                                        
                                                                        objm=Menuoption("")
                                                                        objm.mainmenufun()
                                                
                                                
                                                else:
                                                        print("Password does not match")    
                                        
        
                                                break
                                else:
                                        print("Username not exist")     # return True  # Username is unique
                        #      break   
                # break
                
OBJsection=Section()
class Home:
        def home(self):
                print("-"*24+"WELLCOME TO FOOD AREA OF HAKHAKBURHAK:"+"-"*24)
                print("select option given in front of choise:")
                print("1: Register\n2: Login\n3: Admin login\n4: Exit ")
                ch=input("Enter choie:[1,2,3,4]")   
                if ch=="1":
                        print("1")
                        OBJsection.reg() 
                elif ch=="2":
                        from tables import TABLE
                        tabclassobj=TABLE()
                        tabclassobj.table_creation()
                        OBJsection.login()     
                elif ch=="3":
                        print("3")
                        OBJsection.adminsection()  
                
                else:
                        print("enter valid choies")
                # print("S")
objhome=Home()
objhome.home()
