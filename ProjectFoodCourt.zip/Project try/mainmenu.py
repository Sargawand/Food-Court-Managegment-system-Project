import tables as tb
# import mysql.connector
# import inde
# from tables import TABLE


class Menuoption:
    
    def __init__(self,a):
        self.a=a
        print(self.a)
    def mainmenufun(self):
        print()
        print("Press no in front of option:")
        print("\n1 Menu card\n2]Order\n3]Bill\n5]Home")

        ch=input("Enter Your Chois:")
        if ch=="1":
            
            tabclassobj=tb.TABLE()
            tabclassobj.menucard(self)
            pass
        elif ch=="2":
            pass
        elif ch=="3":
            pass
        elif ch=="4":
            pass
        elif ch=="5":
            pass
        elif ch=="6":
            pass
        
# objmainmenu=Menuoption()
# objmainmenu.mainmenufun()
